const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
require('dotenv').config();

// Import routes
const authRoutes = require('./routes/auth');
const userRoutes = require('./routes/users');
const skillRoutes = require('./routes/skills');
const swapRoutes = require('./routes/swaps');
const feedbackRoutes = require('./routes/feedback');
const adminRoutes = require('./routes/admin');
const reportRoutes = require('./routes/reports');

// Import utilities
const { verifyEmailConfig } = require('./utils/email');
const { query } = require('./config/database');

const app = express();
const PORT = process.env.PORT || 3000;

// Security middleware
app.use(helmet({
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
            fontSrc: ["'self'", "https://fonts.gstatic.com"],
            scriptSrc: ["'self'", "https://unpkg.com"],
            imgSrc: ["'self'", "data:", "https:"],
        },
    },
}));

// CORS configuration
app.use(cors({
    origin: process.env.FRONTEND_URL || 'http://localhost:3000',
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization']
}));

// Rate limiting
const limiter = rateLimit({
    windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000, // 15 minutes
    max: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS) || 100, // limit each IP to 100 requests per windowMs
    message: {
        success: false,
        message: 'Too many requests from this IP, please try again later.'
    },
    standardHeaders: true,
    legacyHeaders: false,
});

app.use(limiter);

// Body parsing middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Health check endpoint
app.get('/health', (req, res) => {
    res.json({
        success: true,
        message: 'Skill Swap Platform API is running',
        timestamp: new Date().toISOString(),
        environment: process.env.NODE_ENV || 'development'
    });
});

// API routes
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/skills', skillRoutes);
app.use('/api/swaps', swapRoutes);
app.use('/api/feedback', feedbackRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/reports', reportRoutes);

// API documentation endpoint
app.get('/api', (req, res) => {
    res.json({
        success: true,
        message: 'Skill Swap Platform API',
        version: '1.0.0',
        endpoints: {
            auth: '/api/auth',
            users: '/api/users',
            skills: '/api/skills',
            swaps: '/api/swaps',
            feedback: '/api/feedback',
            admin: '/api/admin',
            reports: '/api/reports'
        },
        documentation: 'API documentation will be available here'
    });
});

// 404 handler
app.use('*', (req, res) => {
    res.status(404).json({
        success: false,
        message: 'Endpoint not found'
    });
});

// Global error handler
app.use((error, req, res, next) => {
    console.error('Global error handler:', error);

    // Handle specific error types
    if (error.name === 'ValidationError') {
        return res.status(400).json({
            success: false,
            message: 'Validation error',
            errors: error.details
        });
    }

    if (error.name === 'UnauthorizedError') {
        return res.status(401).json({
            success: false,
            message: 'Unauthorized access'
        });
    }

    // Default error response
    res.status(500).json({
        success: false,
        message: process.env.NODE_ENV === 'production' 
            ? 'Internal server error' 
            : error.message
    });
});

// Initialize admin user if it doesn't exist
const initializeAdmin = async () => {
    try {
        const adminExists = await query(
            'SELECT id FROM users WHERE email = $1',
            [process.env.ADMIN_EMAIL]
        );

        if (adminExists.rows.length === 0) {
            const bcrypt = require('bcryptjs');
            const passwordHash = await bcrypt.hash(process.env.ADMIN_PASSWORD, 12);

            await query(
                `INSERT INTO users (email, password_hash, first_name, last_name, is_admin, email_verified)
                 VALUES ($1, $2, $3, $4, $5, $6)`,
                [
                    process.env.ADMIN_EMAIL,
                    passwordHash,
                    'Admin',
                    'User',
                    true,
                    true
                ]
            );

            console.log('Admin user created successfully');
        } else {
            console.log('Admin user already exists');
        }
    } catch (error) {
        console.error('Failed to initialize admin user:', error);
    }
};

// Initialize default skills
const initializeDefaultSkills = async () => {
    try {
        const defaultSkills = [
            { name: 'JavaScript', category: 'Programming' },
            { name: 'Python', category: 'Programming' },
            { name: 'React', category: 'Web Development' },
            { name: 'Node.js', category: 'Web Development' },
            { name: 'Photoshop', category: 'Design' },
            { name: 'Illustrator', category: 'Design' },
            { name: 'Excel', category: 'Office' },
            { name: 'PowerPoint', category: 'Office' },
            { name: 'Cooking', category: 'Lifestyle' },
            { name: 'Photography', category: 'Creative' },
            { name: 'Guitar', category: 'Music' },
            { name: 'Piano', category: 'Music' },
            { name: 'Spanish', category: 'Language' },
            { name: 'French', category: 'Language' },
            { name: 'Yoga', category: 'Fitness' },
            { name: 'Meditation', category: 'Wellness' },
            { name: 'Writing', category: 'Creative' },
            { name: 'Drawing', category: 'Art' },
            { name: 'Video Editing', category: 'Media' },
            { name: 'Public Speaking', category: 'Communication' }
        ];

        for (const skill of defaultSkills) {
            const existingSkill = await query(
                'SELECT id FROM skills WHERE LOWER(name) = LOWER($1)',
                [skill.name]
            );

            if (existingSkill.rows.length === 0) {
                await query(
                    'INSERT INTO skills (name, category, is_approved) VALUES ($1, $2, $3)',
                    [skill.name, skill.category, true]
                );
            }
        }

        console.log('Default skills initialized');
    } catch (error) {
        console.error('Failed to initialize default skills:', error);
    }
};

// Start server
const startServer = async () => {
    try {
        // Test database connection
        await query('SELECT NOW()');
        console.log('Database connection successful');

        // Verify email configuration
        await verifyEmailConfig();

        // Initialize admin user and default skills
        await initializeAdmin();
        await initializeDefaultSkills();

        // Start server
        app.listen(PORT, () => {
            console.log(`🚀 Skill Swap Platform API server running on port ${PORT}`);
            console.log(`📊 Health check: http://localhost:${PORT}/health`);
            console.log(`📚 API documentation: http://localhost:${PORT}/api`);
            console.log(`🌍 Environment: ${process.env.NODE_ENV || 'development'}`);
        });
    } catch (error) {
        console.error('Failed to start server:', error);
        process.exit(1);
    }
};

// Handle graceful shutdown
process.on('SIGTERM', () => {
    console.log('SIGTERM received, shutting down gracefully');
    process.exit(0);
});

process.on('SIGINT', () => {
    console.log('SIGINT received, shutting down gracefully');
    process.exit(0);
});

// Start the server
startServer(); 